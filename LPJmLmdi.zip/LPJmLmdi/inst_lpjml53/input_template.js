/**************************************************************************************/
/**                                                                                \n**/
/**       i  n  p  u  t  _  t  e  m  p  l  a  t  e  .  j  s                        \n**/
/**                                                                                \n**/
/** Configuration file for input dataset for LPJ C Version 5.3.001                 \n**/
/**                                                                                \n**/
/** (C) Potsdam Institute for Climate Impact Research (PIK), see COPYRIGHT file    \n**/
/** authors, and contributors see AUTHORS file                                     \n**/
/** This file is part of LPJmL and licensed under GNU AGPL Version 3               \n**/
/** or later. See LICENSE file or go to http://www.gnu.org/licenses/               \n**/
/** Contact: https://gitlab.pik-potsdam.de/lpjml                                   \n**/
/**                                                                                \n**/
/**************************************************************************************/

#include "include/conf.h" /* include constant definitions */

"soilmap" : [null,"clay", "silty clay", "sandy clay", "clay loam", "silty clay loam",
             "sandy clay loam", "loam", "silt loam", "sandy loam", "silt",
             "loamy sand", "sand", "rock and ice"],

"input" :
{
  "soil" :         { "fmt" : "raw",  "name" : "SOILCODE_FILE"},
  "coord" :        { "fmt" : "clm",  "name" : "GRID_FILE"},
  //"countrycode" :  { "fmt" : "clm",  "name" : "COUNTRY_FILE"},
  //"landuse" :      { "fmt" : "clm",  "name" : "LANDUSE_FILE"},
  /* insert prescribed sdate file name here */
  //"grassland_fixed_pft" : { "fmt" : "raw", "name" : "/home/rolinski/LPJ/Newinput/scenario_MO0.bin"},
  "lakes" :        { "fmt" : "meta", "name" : "/p/projects/lpjml/input/historical/input_VERSION2/glwd_lakes_and_rivers.descr"},
  "drainage" :     { "fmt" : "clm",  "name" : "/p/projects/lpjml/input/historical/input_VERSION2/drainagestn.bin"},
  //"neighb_irrig" : { "fmt" : "clm",  "name" : "/p/projects/lpjml/input/historical/input_VERSION2/neighb_irrig_stn.bin"},
  //"elevation" :    { "fmt" : "clm",  "name" : "/p/projects/lpjml/input/historical/input_VERSION2/elevation.bin"},
  //"reservoir" :    { "fmt" : "clm",  "name" : "/p/projects/lpjml/input/historical/input_VERSION2/reservoir_info_grand5.bin"},
  "temp" :         { "fmt" : "clm",  "name" : "TMP_FILE"},
  "prec" :         { "fmt" : "clm",  "name" : "PRE_FILE"},
  "lwdown" :        { "fmt" : "clm",  "name" : "LWDOWN_FILE"},
  "swdown" :       { "fmt" : "clm",  "name" : "SWDOWN_FILE"},
  //"cloud":         { "fmt" : "clm",  "name" : "/p/projects/lpjml/input/historical/CRUDATA_TS3_23/cru_ts3.23.1901.2014.cld.dat.clm"},
  "wind":          { "fmt" : "clm",  "name" : "WINDSPEED_FILE"},
  //"tamp":          { "fmt" : "clm",  "name" : "/p/projects/lpjml/input/historical/CRUDATA_TS3_23/cru_ts3.23.1901.2014.dtr.dat.clm"}, /* diurnal temp. range */
  "tmin":          { "fmt" : "clm",  "name" : "TMIN_FILE"},
  "tmax":          { "fmt" : "clm",  "name" : "TMAX_FILE"},
  //"humid":         { "fmt" : "clm",  "name" : "HUMID_FILE"},
  "lightning":     { "fmt" : "clm",  "name" : "LIGHTNING_FILE"},
  "firestop":      { "fmt" : "cdf", "var" : "firestop", "name" : "/p/projects/lpjml/calibration/input/firestop_big_h.nc"},
  "human_ignition": { "fmt" : "clm", "name" : "HUMANIGN_FILE"},
  "popdens" :      { "fmt" : "clm",  "name" : "POPDENS_FILE"},
  //"burntarea" :    { "fmt" : "clm",  "name" : "BURNTAREA_FILE"},
  //"landcover":     { "fmt" : "clm",  "name" : "LANDCOVER_FILE"},/*synmap_koeppen_vcf_NewPFT_adjustedByLanduse_SpinupTransitionPrescribed_forLPJ.clm*/
  "co2" :          { "fmt" : "txt",  "name" : "/p/projects/lpjml/input/historical/input_VERSION2/co2_1841-2018.dat"},
  //"wetdays" :      { "fmt" : "clm",  "name" : "/p/projects/lpjml/input/historical/CRUDATA_TS3_23/gpcc_v7_cruts3_23_wet_1901_2013.clm"},
  //"wateruse" :     { "fmt" : "clm",  "name" : "/p/projects/lpjml/input/historical/input_VERSION2/wateruse_1900_2000.bin" }, /* water consumption for industry,household and livestock */
  "no3deposition" : { "fmt" : "clm",  "name" : "NO3DEPOSITION_FILE"},
  "nh4deposition" : { "fmt" : "clm",  "name" : "NH4DEPOSITION_FILE"},
  "soilpH" :        { "fmt" : "clm",  "name" : "SOILPH_FILE"}//,
  //"fertilizer_nr" : { "fmt" : "clm",  "name" : "FERTILIZERNR_FILE"}

},
