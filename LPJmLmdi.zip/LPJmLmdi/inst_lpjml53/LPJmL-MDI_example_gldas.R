#--------------------------------------------------------------------------------
# NAME: 
filename <- "LPJmL-MDI_example.R"
# PROJECT: Example script for the use of LPJmL-MDI
# CREATION DATE: 2015-09-24
# AUTHOR: Matthias Forkel, mforkel@bgc-jena.mpg.de
# UPDATE: 
#--------------------------------------------------------------------------------


#---------------------------------------------------------------------
# 1. Set directories, load packages and define optimization experiment
#---------------------------------------------------------------------


# define directories
#-------------------

rm(list=ls(all=TRUE))
for (i in 1:10) gc()
options(error=traceback)

# paths
path.me <- "/p/projects/" # main directory
# path.me <- "Z://"
path.geodata <- paste0(path.me, "biodiversity/validation_data/data201807/") # directory with data
path.lpj.fun <- paste0(path.me, "biodiversity/drueke/LPJmLmdi_5.1/LPJmLmdi/") # LPJmL-MDI package
path.lpj.input <- paste0("/p/projects/lpjml/input/GLDAS/INPUT/") # LPJmL input data
path.lpj <- paste0(path.me, "biodiversity/drueke/LPJ/Nitrogen_SPITFIRE/LPJmL_internal/") # LPJmL installation
#path.tmp <- "/home/drueke/mdi/" # temporay model outputs

path.tmp <- "/p/tmp/drueke/LPJmLmdi/" # temporay model outputs
dir.create(path.tmp, recursive=TRUE)
path.out <- paste0("/p/projects/biodiversity/drueke/LPJmLmdi_optim/")
dir.create(path.out, recursive=TRUE)


# load packages and functions
#----------------------------

# load packages
library(LPJmLmdi)
library(raster)
library(plyr)
library(plotrix) 
library(rgenoud)
#library(snow)
#library(doSNOW)
#library(RColorBrewer)
#library(quantreg)
#library(numDeriv)

# load functions of the LPJmL-MDI package
setwd(paste0(path.lpj.fun, "R/"))
files <- list.files(pattern=".R")
for (i in 1:length(files)) source(files[i])

setwd(paste0(path.lpj.fun, "data/"))
load("data110.RData")
 
# define the optimization experiment
region <- "tropical"
ncell <- 102  # number of grid cells for optimization (max. 100 are prepared)
costfun <- "KGEw" # KGE, KGEw (default)

# name of grid - read from file with sampled cells
grid.name <- paste(region, ncell, sep="_")
grid.name

# name of the optimization experiment: base name for all output files
name <- paste(grid.name, "_KGEw", sep="-") 	
#name <- gsub("--", "-", name, fixed=TRUE)
#name <- gsub("-_", "_", name, perl=TRUE)
#name <- gsub("-_", "_", name, perl=TRUE)
name

if (!exists("costfun")) costfun <- "KGEw" # default
if (costfun == "KGEw") CostMDS <- CostMDS.KGEw
if (costfun == "KGE") CostMDS <- CostMDS.KGE
if (costfun == "SSE") CostMDS <- CostMDS.SSE
 
# define optimization experiment
#-------------------------------

# define the optimization experiment
name <- "trop_1_b_nolu" 	# name of the optimization experiment: base name for all output files
calcnew <- TRUE 		# extract LPJmL forcing data for the selected grid cells or take previously extracted data?
#CostMDS <- CostMDS.KGE 	# cost function for multiple data sets
restart <- 1	# restart from previous optimization experiment? 
						# 	0 = no restart
              					#	1 = continue with optimization
						#	2 = do only post-processing of optimization results
parallel.lpj <- TRUE
lpjcmd <- "./bin/lpjml"
if (parallel.lpj) lpjcmd <- "timeout 120 srun ./bin/lpjml"


path.rescue <- NULL 	# directory with rescue files to restart from previous optimization (restart > 0)

# settings for genetic optimization
nodes <- 1 				# number of cluster nodes for parallel computing within genoud()
pop.size <- 800  # population size: 10 for testing, production run should have 800-1000
max.generations <- 20 	# maximum number of generations: 10 for testing, production run 20-60
wait.generations <- 21	# minimum number of gnereations to wait before optimum parameter set is returned
BFGSburnin <- max.generations+1		# number of generations before the gradient search algorithm if first used


# remove temporary files at scratch? uncomment if you have two jobs at the same machine
system(paste("rm -rf", path.tmp)) 
system(paste("mkdir", path.tmp)) 


#----------------------------
# 2. Prepare LPJmL input data
#----------------------------

# select grid cells for optimization
#-----------------------------------

# Carefully select grid cells that are representative for the process or PFT that you want to optimize!
# For example, to optimize phenology of the boreal needle-leaved summergreen PFT, we need grid cells where this PFT is growing and has a dominant coverage:


if (grepl("boreal", grid.name)) grid <- read.table("LPJmLmdi/inst_wvpd/Cells_sampled_boreal_v2.csv", header=TRUE, sep=",")

if (grepl("temperate", grid.name)) grid <- read.table("LPJmLmdi/inst_wvpd/Cells_sampled_temperate_v2.csv", header=TRUE, sep=",")

if (grepl("tropical", grid.name)) grid <- read.table("/p/projects/biodiversity/drueke/LPJmLmdi_5.1/LPJmLmdi/inst_wvpd/Cells_sampled_tropical_v2.csv", header=TRUE, sep=",")

grid <- data.frame(lon=grid$lon, lat=grid$lat)

# sample cells?
if (ncell < 100) {
  s <- round(seq(1, nrow(grid), length=ncell), 0)
  grid <- grid[s, ] 
}



# define LPJmL input data
#------------------------

files.clm <- c(
	# monthly CRU and ERI data:
	TMP_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.Tair_f_inst.clm", sep="/"),
	PRE_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.Prec.clm", sep="/"),
	SWDOWN_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.SWdown_f_tavg.clm", sep="/"),
	LWNET_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.Lwnet_tavg.clm", sep="/"),
		
	# extra data:
	WINDSPEED_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.Wind_f_inst.clm", sep="/"),
	#DTR_FILE = paste(path.lpj.input, "cru3-2/cru_ts3.20.1901.2011.dtr.dat.clm", sep="/"),
	BURNTAREA_FILE = paste(path.lpj.input, "mburntarea.clm", sep="/"),
	#DRAINCLASS_FILE = paste(path.lpj.input, "drainclass.bin", sep="/"),
	SOILCODE_FILE = paste(path.lpj.input, "soil_GLDAS.bin", sep="/"),
	#WET_FILE = paste("/p/projects/lpjml/input/historical/CRUDATA_TS3_23/gpcc_v7_cruts3_23_wet_1901_2013.clm", sep="/"),
	TMIN_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.Tair_min.clm", sep="/"),
	TMAX_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.Tair_max.clm", sep="/"),
	HUMID_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.Qair_f_inst.clm", sep="/"),
	LIGHTNING_FILE = paste(path.lpj.input, "dlightning.clm", sep="/"),
	POPDENS_FILE = paste(path.lpj.input, "popdens_GLDAS.clm", sep="/"),
	HUMANIGN_FILE = paste(path.lpj.input, "human_ignition_GLDAS.clm", sep="/"),
	LANDUSE_FILE = paste(path.lpj.input, "landuse_GLDAS.clm", sep="/"),
	COUNTRY_FILE = paste(path.lpj.input, "country_GLDAS.clm", sep="/"),
	LANDCOVER_FILE = paste(path.lpj.input, "landcover_gldas.clm", sep="/"),
	NO3DEPOSITION_FILE = paste(path.lpj.input, "no3_deposition_rcp8p5_GLDAS.clm", sep="/"),
	NH4DEPOSITION_FILE = paste(path.lpj.input, "nh4_deposition_rcp8p5_GLDAS.clm", sep="/"),
	SOILPH_FILE = paste(path.lpj.input, "soil_ph_GLDAS.clm", sep="/"),
	FERTILIZERNR_FILE = paste(path.lpj.input, "fertilizer_ggcmi_GLDAS.clm2", sep="/")

)

input.df <- RegridLPJinput(files.clm, "/p/projects/lpjml/input/GLDAS/INPUT/grid_GLDAS.clm", grid, "/p/tmp/drueke/LPJmLmdi_input")


#------------------------------------------
# 3. Define LPJmL directories and templates 
#------------------------------------------


# LPJmL directories and configuration template files
dir.create(path.tmp)
lpjfiles <- LPJfiles(path.lpj = path.lpj, path.tmp = path.tmp, path.out = path.out, 
	sim.start.year = 1948, sim.end.year = 2011,											# starting year of transient simulation
	lpj.conf = paste0(path.lpj.fun, "inst_wvpd/lpjml_template.js"), 	# template file for LPJmL configuration 
	param.conf = paste0(path.lpj.fun, "inst_wvpd/param_template.js"), 	# template file	for parameter configuration 
	pft.par = paste0(path.lpj.fun, "inst_wvpd/pft_template.js"), 		# template file for PFT-specific parameters 
	param.par = paste0(path.lpj.fun, "inst_wvpd/lpjparam_template.js"), 	# template file for global parameters 
	input.conf = paste0(path.lpj.fun, "inst_wvpd/input_template.js"), 	# template file for input data 
	input=input.df) 	
	


#------------------------------------
# 4. Define and read integration data
#------------------------------------

# define all integration data sets

ndaymonth <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31) # convert gC m-2 day-1 -> gC m-2 month-1


mod.fapar <- IntegrationDataset(
  name="FAPAR", unit="-",
  data.val.file = paste0(path.geodata, "MOD15A2.FAPAR.360.720.2000.2015.30days.nc"),
  data.unc.file = paste0(path.geodata, "MOD15A2.FAPAR-unc.360.720.2000.2015.30days.nc"),
  data.time = seq(as.Date("2000-01-01"), as.Date("2015-12-01"), by="month"),
  model.time = seq(as.Date("2000-01-01"), as.Date("2015-12-01"), by="month"),
  model.val.file = "mfapar.bin",
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)


fluxcom.gpp <- IntegrationDataset(
  name="GPP", unit="gC m-2 mon-1",
  data.val.file = paste0(path.geodata, "FLUXCOMmet.GPP.360.720.1982.2010.30days.nc"),
  data.unc.file = paste0(path.geodata, "FLUXCOMmet.GPP-unc.360.720.1982.2010.30days.nc"),
  data.time = seq(as.Date("1982-01-01"), as.Date("2010-12-01"), by="month"),
  model.time = seq(as.Date("1982-01-01"), as.Date("2010-12-01"), by="month"),
  model.val.file = "mgpp.bin",
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

avithu.agb <- IntegrationDataset(
  name="AGB", unit="gC m-2",
  data.val.file = paste0(path.geodata, "AviThu.ABCtree.292.720.2010.2010.0.nc"),
  data.unc.file = paste0(path.geodata, "AviThu.ABCtree-unc.292.720.2010.2010.0.nc"),
  data.time = as.Date("2010-01-01"),
  model.time = seq(as.Date("2009-01-01"), as.Date("2011-12-01"), by="month"),
  model.val.file = "agb_tree.bin",
  xy = grid, AggFun = AggNULLMean, data.factor=1000, cost=TRUE, CostFunction=SSE, weight=1)

cci.herb <- IntegrationDataset(
  name="FPC Herb", unit="",
  data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.Herb.348.720.2003.2003.0.nc"),
  data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.Herb_unc.348.720.2003.2003.0.nc"),
  data.time = as.Date("2003-01-01"),
  model.time = as.Date("2003-01-01"), # but read data for 1992-2015 with the function:
  model.val.file = function() { # aggregate all herb PFTs
    x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
    # Herb = TrH + TeH + PoH
    trh <- x@data[, seq(10, ncol(x@data), by=12)]*x@data[, seq(1, ncol(x@data), by=12)] # TrH = 10th PFT
    teh <- x@data[, seq(11, ncol(x@data), by=12)]*x@data[, seq(1, ncol(x@data), by=12)] # TeH = 11th PFT
    poh <- x@data[, seq(12, ncol(x@data), by=12)]*x@data[, seq(1, ncol(x@data), by=12)] # PoH = 12th PFT
    herb <- trh + teh + poh
    x@data <- data.frame(rowMeans(herb)) # mean over time
    return(x)
  },
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)


# tropical PFTs
#--------------

if (grepl("tropical", grid.name)) {
  cci.trbe <- IntegrationDataset(
    name="FPC TrBE", unit="",
    data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.TrBE.348.720.1992.2015.365days.nc"),
    data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.TrBE_unc.348.720.1992.2015.365days.nc"),
    data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.val.file = function() {
      x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
      x@data <- x@data[, seq(2, ncol(x@data), by=12)]*x@data[, seq(1, ncol(x@data), by=12)] # 2 band in FPC
      return(x)
    },
    xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)
  
  cci.trbr <- IntegrationDataset(
    name="FPC TrBR", unit="",
    data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.TrBR.348.720.1992.2015.365days.nc"),
    data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.TrBR_unc.348.720.1992.2015.365days.nc"),
    data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.val.file = function() {
      x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
      x@data <- x@data[, seq(3, ncol(x@data), by=12)]*x@data[, seq(1, ncol(x@data), by=12)] # 3 band in FPC
      return(x)
    },
    xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)
  
  #integrationdata <- IntegrationData(mod.fapar, avithu.agb, cci.trbe, cci.trbr, cci.herb, fluxcom.gpp)
  integrationdata <- IntegrationData(mod.fapar, avithu.agb, fluxcom.gpp)
}


# boreal PFTs
#------------

if (grepl("boreal", grid.name)) {

  cci.bone <- IntegrationDataset(
    name="FPC BoNE", unit="",
    data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.BoNE.348.720.1992.2015.365days.nc"),
    data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.BoNE_unc.348.720.1992.2015.365days.nc"),
    data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.val.file = function() {
      x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
      x@data <- x@data[, seq(7, ncol(x@data), by=12)] # 7 band in FPC
      return(x)
    },
    xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)
  
  cci.bons <- IntegrationDataset(
    name="FPC BoNS", unit="",
    data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.BoNS.348.720.1992.2015.365days.nc"),
    data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.BoNS_unc.348.720.1992.2015.365days.nc"),
    data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.val.file = function() {
      x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
      x@data <- x@data[, seq(9, ncol(x@data), by=12)] # 9 band in FPC
      return(x)
    },
    xy = grid, AggFun = NULL, data.factor=NULL, cost=use.tree, CostFunction=SSE, weight=1)
  
  cci.bobs <- IntegrationDataset(
    name="FPC BoBS", unit="",
    data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.BoBS.348.720.1992.2015.365days.nc"),
    data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.BoBS_unc.348.720.1992.2015.365days.nc"),
    data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.val.file = function() {
      x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
      x@data <- x@data[, seq(8, ncol(x@data), by=12)] # 8 band in FPC
      return(x)
    },
    xy = grid, AggFun = NULL, data.factor=NULL, cost=use.tree, CostFunction=SSE, weight=1)
  
  # cci.poh <- IntegrationDataset(
  #   name="FPC PoH", unit="",
  #   data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.PoH.348.720.1992.2015.365days.nc"),
  #   data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.PoH_unc.348.720.1992.2015.365days.nc"),
  #   data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  #   model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  #   model.val.file = function() {
  #     x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
  #     x@data <- x@data[, seq(12, ncol(x@data), by=12)] # 12 band in FPC
  #     return(x)
  #   },
  #   xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

  # make list of IntegrationData
  # integrationdata <- IntegrationData(mod.fapar, gome2.sif, avithu.agb, cci.bone, cci.bons, cci.bobs, cci.poh, fluxcom.gpp, cci.ba)
  integrationdata <- IntegrationData(mod.fapar, gome2.sif, avithu.agb, cci.bone, cci.bons, cci.bobs, cci.herb, fluxcom.gpp, cci.ba)
  
}


# temperate PFTs
#---------------

if (grepl("temperate", grid.name)) {
  
  cci.tene <- IntegrationDataset(
    name="FPC TeNE", unit="",
    data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.TeNE.348.720.1992.2015.365days.nc"),
    data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.TeNE_unc.348.720.1992.2015.365days.nc"),
    data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.val.file = function() {
      x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
      x@data <- x@data[, seq(4, ncol(x@data), by=12)] # 4 band in FPC
      return(x)
    },
    xy = grid, AggFun = NULL, data.factor=NULL, cost=use.tree, CostFunction=SSE, weight=1)
  
  cci.tebs <- IntegrationDataset(
    name="FPC TeBS", unit="",
    data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.TeBS.348.720.1992.2015.365days.nc"),
    data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.TeBS_unc.348.720.1992.2015.365days.nc"),
    data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.val.file = function() {
      x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
      x@data <- x@data[, seq(6, ncol(x@data), by=12)] # 6 band in FPC
      return(x)
    },
    xy = grid, AggFun = NULL, data.factor=NULL, cost=use.tree, CostFunction=SSE, weight=1)
  
  cci.tebe <- IntegrationDataset(
    name="FPC TeBE", unit="",
    data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.TeBE.348.720.1992.2015.365days.nc"),
    data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.TeBE_unc.348.720.1992.2015.365days.nc"),
    data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
    model.val.file = function() {
      x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
      x@data <- x@data[, seq(5, ncol(x@data), by=12)] # 5 band in FPC
      return(x)
    },
    xy = grid, AggFun = NULL, data.factor=NULL, cost=use.tree, CostFunction=SSE, weight=1)
  
  # cci.teh <- IntegrationDataset(
  #   name="FPC TeH", unit="",
  #   data.val.file = paste0(path.geodata, "ESA-CCI-LCv207.TeH.348.720.1992.2015.365days.nc"),
  #   data.unc.file = paste0(path.geodata, "ESA-CCI-LCv207.TeH_unc.348.720.1992.2015.365days.nc"),
  #   data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  #   model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  #   model.val.file = function() {
  #     x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
  #     x@data <- x@data[, seq(11, ncol(x@data), by=12)] # 11 band in FPC
  #     return(x)
  #   },
  #   xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)
  
  # make list of IntegrationData
  # integrationdata <- IntegrationData(mod.fapar, gome2.sif, avithu.agb, cci.tebs, cci.tene, cci.tebe, cci.teh, fluxcom.gpp, cci.ba)
  integrationdata <- IntegrationData(mod.fapar, gome2.sif, avithu.agb, cci.tebs, cci.tene, cci.tebe, cci.herb, fluxcom.gpp, cci.ba)
  
}

	
# make list of IntegrationData
#pdf("out.pdf")
#plot(integrationdata, 1)
#plot(integrationdata, 2)
#dev.off()
	
#--------------------------------------------------
# 5. Define LPJmL prior parameter values and ranges
#--------------------------------------------------

# Depending on your application, you might need to define additional parameters in param_template.par and pft_template.par


# read parameter priors and ranges from *.txt file
#-------------------------------------------------

# It is helpful to save all parameter names, prior values and prior ranges in a Excel table or *.csv file

setwd(path.lpj.fun)
par.df <- read.table("/p/projects/biodiversity/drueke/LPJmLmdi_5.1/LPJmLmdi/inst_wvpd/LPJmL_parameter-table.csv", header=TRUE, sep=",")

# make LPJpar object
lpjpar <- LPJpar(par.prior=par.df$par.prior, par.lower=par.df$par.lower, par.upper=par.df$par.upper, par.pftspecif=par.df$par.pftspecif, par.names=par.df$par.names, correct=TRUE)

pdf("LPJmL_parameter-table.pdf")
#plot(lpjpar) 
# plot(lpjpar, "ALBEDO_LEAF")
dev.off()

#setwd(paste0(path.lpj, "par/"))
#WriteLPJpar(lpjpar, file="LPJmLmdi_test", pft.par=paste0(path.lpj.fun, "inst_gldas/pft_template.js"), param.par=paste0(path.lpj.fun, "inst_gldas/lpjparam_template.js")) 


# select parameters for optimization
#-----------------------------------

# Which parameters should be included in optimization?
par.optim <- c("BETA_ROOT", "ALPHAA", "TEMP_PHOTOS_LOW", "TEMP_PHOTOS_HIGH", "LIGHTEXTCOEFF", "TMIN_SLOPE", "TMIN_BASE", "TMAX_BASE", "TMAX_SLOPE", "WSCAL_BASE", "WSCAL_SLOPE", "TMAX_BASE", "TMAX_SLOPE", "LIGHT_BASE", "LIGHT_SLOPE", "LONGEVITY", "TURNOVER_SAPWOOD", "TURNOVER_LEAF", "MORT_MAX", "K_EST", "VMAX_UP", "kNMIN", "KNMIN", "KNSTORE", "FN_TURNOVER")# "CROWN_MORT_RCK_TrBE", "CROWN_MORT_RCK_TrBR", "SCORCHHEIGHT_F_TrBR", "SCORCHHEIGHT_F_TrBE")

if (grepl("tropical", grid.name)) pft.sel <- c("TrBE", "TrBR", "TrH")
if (grepl("temperate", grid.name)) pft.sel <- c("TeNE", "TeBE", "TeBS", "TeH")
if (grepl("boreal", grid.name)) pft.sel <- c("BoNE", "BoNS", "BoBS", "PoH")

# use only parameters that are defined for the PFT
par.optim <- paste(rep(par.optim, each=length(pft.sel)), pft.sel, sep="_")
par.optim <- par.optim[par.optim %in% lpjpar$names]


#md: add global parameters?

par.optim <- c(par.optim, "THETA", "ALPHAC3", "ALPHAC4", "K_MORT", "UP_T_M", "T_O", "T_R")



# exclude 'inactive' parameters
b <- match(par.optim, lpjpar$names)
rem <- lpjpar$prior[b] == 999 | lpjpar$prior[b] == -999
par.optim <- par.optim[!rem]
par.optim



# For which PFTs?
#pft.sel <- c("BoNS", "PoH")
#par.optim <- paste(rep(par.optim, each=length(pft.sel)), pft.sel, sep="_")
#par.optim


#------------------------
# 6. Perform optimization
#------------------------


# do optimization
OptimizeLPJgenoud(xy = grid, 				# matrix of grid cell coordinates to run LPJ
	name = name, 							# name of the experiment (basic file name for all outputs)
	lpjpar = lpjpar,						# see LPJpar
	par.optim = par.optim,			        # names of the parameters in LPJpar that should be optimized
	lpjfiles = lpjfiles,					# see LPJfiles
	copy.input = FALSE, 						# Should LPJmL input data be copied to the directory for temporary output? 
	integrationdata = integrationdata,		# see IntegrationData
	plot = TRUE,							# plot results?
	pop.size = pop.size, 					# population size
	max.generations = max.generations, 		# max number of generations
	wait.generations = wait.generations,	# minimum number of generations to wait
	BFGSburnin = BFGSburnin,				# number of generations before the gradient search algorithm if first used
	calc.jacob = FALSE, 					# Compute Hessian and Jacobian (yes = TRUE, no = FALSE)?
	restart = restart, 						# Restart? 0 = at beginning, 1 = continue with genoud, 2 = post-processing
	path.rescue = path.rescue, 				# directory with 'resuce' files from a previous optimization if restart > 0
	restart.jacob = FALSE, 					# Compute Hessian and Jacobian if restart > 0 (yes = TRUE, no = FALSE)? 
	nodes = nodes, 							# How many nodes to use for parallel computing within genoud?
	maxAutoRestart = max.generations-1, 	# maximum number of automatic restarts in case something crashes
	warnings = TRUE,
	runonly=FALSE,							# make only model run (TRUE) or do full optimization?
	CostMDS=CostMDS)						# Cost function for multiple data stes to use


# # check the progress of the optimization:
 #setwd("/p/projects/biodiversity/drueke/internal_lpjml/out_optim/opt_Example/Opt_test4/Opt_test4_rescue") # directory with rescue files
 #files <- list.files(pattern=".RData") 
 #rescue <- CombineRescueFiles(files, remove=FALSE)
 #pdf("progress.pdf")
 #plot(rescue)
 #dev.off()
