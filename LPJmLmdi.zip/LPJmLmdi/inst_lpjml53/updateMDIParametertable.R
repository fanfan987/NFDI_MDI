library(readxl)
library(tidyr)

#Path to file on the cloud
cloudfolder <-  "/p/projects/landuse/users/wirth/LPJmL/mdi_calibration/LPJmLmdi/inst_lpjml53/"
#Path and filename of file on git
#mdicsv <- "/p/projects/landuse/users/wirth/LPJmL/mdi_calibration/LPJmLmdi/inst_lpjml53/LPJmL_parameter-table.csv"
mdicsv <- "/home/cmueller/lpj_git/mdi_calibration/LPJmLmdi/inst_lpjml53/LPJmL_parameter-table.csv"

#Reading and transforming the data from the cloud.
pftranges <- read_xlsx(path = paste0(cloudfolder, "Parameter_values.xlsx"), sheet = 1, skip = 2, col_names = FALSE, col_types = c("text", rep("numeric", 22)))

pftnames <- as.vector(read_xlsx(path = paste0(cloudfolder, "Parameter_values.xlsx"), sheet = 1, col_names = FALSE)[1,])
pftnames <- pftnames[!is.na(pftnames)]


pfts <- pftnames

pftnames <- c(pftnames[1], paste0(rep(pftnames[2:length(pftnames)], each=2), c(".min", ".max")))
colnames(pftranges) <- pftnames


pftranges <- pivot_longer(data = pftranges, cols = c(2:ncol(pftranges)), names_to = "PFT.boundary", values_to = "value")


pftranges[,c("PFT", "boundary")] <- matrix(unlist(strsplit(pftranges$PFT.boundary, split="[.]")), ncol=2, byrow=T)
pftranges <- pftranges[,-2]

pftranges <- pivot_wider(data = pftranges, names_from = boundary, values_from = value)

pftdef <- read_xlsx(path = paste0(cloudfolder, "Parameter_values.xlsx"), sheet = 3, col_types = c("text", rep("numeric", 11)))
colnames(pftdef) <-pfts# c(pfts[1], paste0(pfts[2:length(pfts)], ".default")) 
pftdef <- pivot_longer(data = pftdef, cols = c(2:ncol(pftdef)), names_to = "PFT", values_to = "default")
#pftdef <- pivot_longer(data = pftdef, cols = c(2:ncol(pftdef)), names_to = "PFT.boundary", values_to = "value")


pftfull <- merge(pftdef, pftranges, by = c("Parameter", "PFT"))

pftfull$Parameter[which(pftfull$Parameter=="b")] <- "bc"

pftfull$identifier <- paste(toupper(pftfull$Parameter), pftfull$PFT, sep="_")
pftfull$identifier[pftfull$Parameter=="kNmin"] <- paste("kNMIN", pftfull$PFT[pftfull$Parameter=="kNmin"], sep="_")


glob <-  read_xlsx(path = paste0(cloudfolder, "Parameter_values.xlsx"), sheet = 4, col_types = c("text", rep("numeric", 3)))
glob$PFT <- "global"
glob$identifier <- toupper(glob$Parameter)
pftandglob <- rbind(pftfull, glob)


#Reading the data from git.
mditable <- read.csv(mdicsv)

#Create Identifiers for the parameters to select and change the values
tropicpftparam <-  c("windspeed_dampening", "vmax_up", "turnover_root", 
"temp_co2_high", "temp_photos_high", "soc_k", "sla",  "knstore", "Knmin", "kNmin",
  "k_litter10_leaf", "gmin", "fuelbulkdensity", "fn_turnover",  "emax", "beta_root",
  "alphaa",  "albedo_leaf")#less important:"reprod_cost"  "alpha_fuelp", "albedo_litter"
tropicglobparam <- c("temp_response", "T_0", "par_sink_limit", "k_mort","kc25","fastfrac","atmfrac","ALPHAM" )#less important "alphac4", "alphac3"

temperatepftparam <-  c("temp_photos_high", "temp_high", "temp_low", "temp_co2_high",
                        "lmro_ratio",   "k_est", "intc",  "gdd5min", "fuelbulkdensity", 
                        "crownarea_max", "cn_ratio_sapwood", "beta_root",  "aphen_max",  "alpha_fuelp",
                        "allom1", "albedo_leaf")
temperateglobparam <- c("temp_response", "par_sink_limit", "kc25","GM","fastfrac","atmfrac","ALPHAM", "alphac4","k_soil10_slow", "k_soil10_fast")

borealpftparam <- c("windspeed_dampening", "twmax_daily", "turnover_root",  "temp_low", "temp_high",
                        "gdd5min", "fuelbulkdensity", "fn_turnover"
                    , "flam",  "cn_ratio_leaf",  "beta_root",  "alpha_fuelp", "allom2")
borealglobparam <- c("temp_response","par_sink_limit","fastfrac","atmfrac", "ALPHAM","bioturbate","q_ash","k_mort","k_litter10")

globparam <- union(union(tropicglobparam, temperateglobparam),borealglobparam)

allid <- c(paste(toupper(tropicpftparam[-which(tropicpftparam %in% c("Knmin", "kNmin"))]), rep(pfts[c(2,3,10)], each=length(tropicpftparam)-2), sep="_"),
              paste(c("KNMIN", "kNMIN"), rep(pfts[c(2,3,10)], each=2), sep="_"),
              paste(toupper(temperatepftparam), rep(pfts[c(4,5,6,11)], each=length(temperatepftparam)), sep="_"),
              paste(toupper(borealpftparam), rep(pfts[c(7,8,9,12)], each=length(borealpftparam)), sep="_"),
              toupper(globparam))


####This part needs to be adapted if parameters change since it requires manual adjustment of identifiers

#check if any of the parameter identifiers is missing in either of the tables
missingcloud <- setdiff(allid, pftandglob$identifier)
missingmdi <- setdiff(allid, mditable$par.names)
#only missing values in git
print(missingmdi)
#First nine are non existent parameters and can be ugnired
nonexistentparams <- missingmdi[1:9]
allid <- allid[-which(allid %in% nonexistentparams)]
missingmdi <- missingmdi[-c(1:9)]
#remaining have different notation in the table in git and the owncloud
correction <- c("T_O", "KC_25", "ALPHA_M", "GMAX", "globK_LITTER10")
#Notation is corrected to match the table in git
for(i in missingmdi){
 pftandglob$identifier[pftandglob$identifier==i] <- correction[which(missingmdi ==i)]
 allid[allid==i] <- correction[which(missingmdi ==i)]
}
#test if there are remaining differences
missingcloud <- setdiff(allid, pftandglob$identifier)
missingmdi <- setdiff(allid, mditable$par.names)

mditablenew <- mditable
#Test is numbers of rows of the subsets match
nrow(mditablenew[which(mditablenew$par.names %in% allid),])
length(globparam)+3*length(tropicpftparam)+4*length(temperatepftparam)+4*length(borealpftparam)-length(nonexistentparams)
length(allid)
#sort data
pftandglob <- pftandglob[order(pftandglob$identifier),]
mditablenew <- mditablenew[order(mditablenew$par.names),]
#Check if data is in right order
print(cbind(mditablenew[which(mditablenew$par.names %in% allid),"par.names"],pftandglob[pftandglob$identifier %in% allid,"identifier"]))
#Change values to match the table
mditablenew[which(mditablenew$par.names %in% allid),paste("par", c("prior", "lower", "upper"), sep=".")] <- pftandglob[pftandglob$identifier %in% allid,c("default", "min", "max")]

write.csv(x = mditablenew, file = mdicsv, row.names = FALSE, quote = TRUE)

