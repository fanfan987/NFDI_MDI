#--------------------------------------------------------------------------------
# NAME: 
filename <- "LPJmL-MDI_example.R"
# PROJECT: Example script for the use of LPJmL-MDI
# CREATION DATE: 2015-09-24
# AUTHOR: Matthias Forkel, mforkel@bgc-jena.mpg.de
# UPDATE: 
#--------------------------------------------------------------------------------


#---------------------------------------------------------------------
# 1. Set directories, load packages and define optimization experiment
#---------------------------------------------------------------------


# define directories
#-------------------

rm(list=ls(all=TRUE))
for (i in 1:10) gc()
options(error=traceback)
options(warn=1) # print warnings as they occur

# paths
path.me <- "/p/projects/" # main directory
# path.me <- "Z://"
path.geodata1 <- paste0(path.me, "amazonas/nfan/Data/fluxnetBGI2021.BRK15.DD/data/") # directory with data
path.geodata2 <- paste0(path.me, "lpjml/calibration/reference_data/")
path.lpj.fun <- paste0("/p/projects/amazonas/nfan/LPJmLmdi/LPJmLmdi/") # LPJmL-MDI package
path.lpj.input <- paste0(path.me, "amazonas/drueke/input_calib/") # LPJmL input data
path.lpj <- paste0("/p/projects/amazonas/nfan/lpjml_branch/") # LPJmL installation
#path.tmp <- "/home/drueke/mdi/" # temporay model outputs

path.tmp <- "/p/projects/amazonas/nfan/tmp/" # temporay model outputs
dir.create(path.tmp, recursive=TRUE)
path.out <- paste0("/p/projects/amazonas/nfan/LPJmLmdi/test/")
dir.create(path.out, recursive=TRUE)

# select region
region_index <- 1 # can be 1-3 for tropical, temperate, boreal

# load packages and functions
#----------------------------

# load packages
library(raster)
library(plyr)
library(plotrix) 
library(rgenoud)
library(snow)
library(doSNOW)
library(RColorBrewer)
#library(LPJmLmdi)
### to replace library LPJmLmdi (as the functions are read below and conflict with oder versions of that library)
### we need to load more libraries
library(ncdf4)
library(ModelDataComp)
library(yarrr)
library(jpeg)
library(BayesFactor)
library(coda)
library(Matrix)
#library(quantreg)
#library(numDeriv)

# load functions of the LPJmL-MDI package
setwd(paste0(path.lpj.fun, "R/"))
files <- list.files(pattern=".R")
for (i in 1:length(files)) source(files[i])

cat("before loading data110\n")
ls() 
setwd(paste0(path.lpj.fun, "data/"))
load("data110.RData") 
cat("\nafter loading data110\n")
ls()
cat("\ndone\n")

ncell <- 18  # number of grid cells for optimization (max. 100 are prepared)

# name of grid - read from file with sampled cells
grid.name <- paste("test")
grid.name

# name of the optimization experiment: base name for all output files
name <- paste(grid.name, "_KGEw", sep="-") 	
#name <- gsub("--", "-", name, fixed=TRUE)
#name <- gsub("-_", "_", name, perl=TRUE)
#name <- gsub("-_", "_", name, perl=TRUE)
name
if (!exists("costfun")) costfun <- "KGE" # default
if (costfun == "KGEw") CostMDS <- CostMDS.KGEw
if (costfun == "KGE") CostMDS <- CostMDS.KGE
if (costfun == "SSE") CostMDS <- CostMDS.SSE

# define optimization experiment
#-------------------------------

# define the optimization experiment
name <- 'boreal_run3'#'fullRun_flag0d5_109sites'         # name of the optimization experiment: base name for all output files
calcnew <- TRUE 		# extract LPJmL forcing data for the selected grid cells or take previously extracted data?
#CostMDS <- CostMDS.KGE 	# cost function for multiple data sets
restart <- 2	# restart from previous optimization experiment? 
# 	0 = no restart
#	1 = continue with optimization
#	2 = do only post-processing of optimization results
parallel.lpj <- TRUE


# This is never passed on to RUnLPJ as that function is called by genoud() without options to modify standard arguments...
#lpjcmd <- "./bin/lpjml"
#if (parallel.lpj) lpjcmd <- "timeout 120 srun ./bin/lpjml"
#lpjcmd <- paste0(path.lpj,"bin/lpjml") 
lpjcmd <- NULL
#if (parallel.lpj) lpjcmd <- paste0("timeout 120 srun ",path.lpj,"/bin/lpjml")
#if (parallel.lpj) lpjcmd <- paste0(path.lpj,"/bin/lpjml")


path.rescue <- NULL 	# directory with rescue files to restart from previous optimization (restart > 0)

# settings for genetic optimization
nodes <- 1 				# number of cluster nodes for parallel computing within genoud()
pop.size <- 800  # population size: 10 for testing, production run should have 800-1000
max.generations <- 20 	# maximum number of generations: 10 for testing, production run 20-60
wait.generations <- 21	# minimum number of gnereations to wait before optimum parameter set is returned
BFGSburnin <- max.generations+1		# number of generations before the gradient search algorithm if first used


# remove temporary files at scratch? uncomment if you have two jobs at the same machine
system(paste("rm -rf", path.tmp)) 
system(paste("mkdir", path.tmp)) 



#----------------------------
# 2. Prepare LPJmL input data
#----------------------------

# select grid cells for optimization
#-----------------------------------

# Carefully select grid cells that are representative for the process or PFT that you want to optimize!
# For example, to optimize phenology of the boreal needle-leaved summergreen PFT, we need grid cells where this PFT is growing and has a dominant coverage:



grid <- read.table(paste0(path.lpj.input,"SiteGridLocation_boreal.txt"), header=TRUE)

grid <- data.frame(lon=grid$lon, lat=grid$lat)

# sample cells?
if (ncell < 100) {
  s <- round(seq(1, nrow(grid), length=ncell), 0)
  grid <- grid[s, ] 
}



# define LPJmL input data
#------------------------

files.clm <- c(
  #GRID_FILE = paste(path.lpj.input, "grid.bin", sep=""),
  # monthly CRU and ERI data:
  TMP_FILE = paste(path.lpj.input, "ERAinterim.v2.Tave.1979.2017.daily.clm", sep=""),
  PRE_FILE = paste(path.lpj.input, "ERAinterim.v2.Precipitation.1979.2017.daily.clm", sep=""),
  SWDOWN_FILE = paste(path.lpj.input, "ERAinterim.v2.SW.1979.2017.daily.clm", sep=""),
  LWDOWN_FILE = paste(path.lpj.input, "ERAinterim.v2.LW.1979.2017.daily.clm", sep=""),
  
  
  # extra data:
  WINDSPEED_FILE = paste(path.lpj.input, "mwindspeed_1860-2100_67420_fluxnet.clm", sep=""),
  #DTR_FILE = paste(path.lpj.input, "cru3-2/cru_ts3.20.1901.2011.dtr.dat.clm", sep="/"),
  #BURNTAREA_FILE = paste(path.lpj.input, "mburntarea.clm", sep="/"),
  #DRAINCLASS_FILE = paste(path.lpj.input, "drainclass.bin", sep="/"),
  SOILCODE_FILE = paste(path.lpj.input, "soil_fluxnet.bin", sep=""),
  #WET_FILE = paste("/p/projects/lpjml/input/historical/CRUDATA_TS3_23/gpcc_v7_cruts3_23_wet_1901_2013.clm", sep="/"),
  #TMIN_FILE = paste(path.lpj.input,region, "tasmin_era5_cal.clm", sep="/"),
  #TMAX_FILE = paste(path.lpj.input,region, "tasmax_era5_cal.clm", sep="/"),
  #HUMID_FILE = paste(path.lpj.input, "GLDAS_NOAH05_daily_1948-2017.Qair_f_inst.clm", sep="/"),
  #LIGHTNING_FILE = paste(path.lpj.input,region, "mlightning_cal.clm", sep="/"),
  #POPDENS_FILE = paste(path.lpj.input,region, "popdens_cal.clm", sep="/"),
  #HUMANIGN_FILE = paste(path.lpj.input,region, "human_ignition_cal.clm", sep="/"),
  #LANDUSE_FILE = paste(path.lpj.input, "landuse_GLDAS.clm", sep="/"),
  #COUNTRY_FILE = paste(path.lpj.input, "country_GLDAS.clm", sep="/"),
  #LANDCOVER_FILE = paste(path.lpj.input, "landcover_gldas.clm", sep="/"),
  NO3DEPOSITION_FILE = paste(path.lpj.input, "no3_deposition_rcp8p5_fluxnet.clm", sep=""),
  NH4DEPOSITION_FILE = paste(path.lpj.input, "nh4_deposition_rcp8p5_fluxnet.clm", sep=""),
  SOILPH_FILE = paste(path.lpj.input, "soil_ph_fluxnet.clm", sep=""),
  FERTILIZERNR_FILE = paste(path.lpj.input, "fertilizer_luh2v2_1900-2015_32bands_fluxnet.clm", sep="")
  
)

input.df <- RegridLPJinput(files.clm, paste(path.lpj.input, "grid.bin", sep=""), grid, path.tmp)
#input.df <- data.frame(name=names(files.clm), file=files.clm)

#------------------------------------------
# 3. Define LPJmL directories and templates 
#------------------------------------------


# LPJmL directories and configuration template files
dir.create(path.tmp)
lpjfiles <- LPJfiles(path.lpj = path.lpj, path.tmp = path.tmp, path.out = path.out, 
                     sim.start.year = 1979, sim.end.year = 2017,											# starting year of transient simulation
                     lpj.conf = paste0(path.lpj.fun, "inst_lpjml53/lpjml_template.js"), 	# template file for LPJmL configuration 
                     param.conf = paste0(path.lpj.fun, "inst_lpjml53/param_template.js"), 	# template file	for parameter configuration 
                     pft.par = paste0(path.lpj.fun, "inst_lpjml53/pft_template.js"), 		# template file for PFT-specific parameters 
                     param.par = paste0(path.lpj.fun, "inst_lpjml53/lpjparam_template.js"), 	# template file for global parameters 
                     input.conf = paste0(path.lpj.fun, "inst_lpjml53/input_template.js"), 	# template file for input data 
                     input=input.df) 	



#------------------------------------
# 4. Define and read integration data
#------------------------------------

# define all integration data sets

ndaymonth <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31) # convert gC m-2 day-1 -> gC m-2 month-1

mod.gpp_fluxnet <- IntegrationDataset(
  name="GPP", unit="gC m-2 mon-1",
  data.val.file = paste0(path.geodata1, "ERAinterim.v2.GPP.1979.2017.monthly_QC_flag0d5.nc"),
  data.unc.file = paste0(path.geodata1, "ERAinterim.v2.GPP.1979.2017.monthly_unc_QC_flag0d5.nc"),
  data.time = seq(as.Date("1979-01-01"), as.Date("2017-12-31"), by="month"),
  model.time = seq(as.Date("1979-01-01"), as.Date("2017-12-31"), by="month"),
  model.val.file = "mgpp.bin",
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

mod.reco_fluxnet <- IntegrationDataset(
  name="Reco", unit="gC m-2 mon-1",
  data.val.file = paste0(path.geodata1, "ERAinterim.v2.Reco.1979.2017.monthly_QC_flag0d5.nc"),
  data.unc.file = paste0(path.geodata1, "ERAinterim.v2.Reco.1979.2017.monthly_unc_QC_flag0d5.nc"),
  data.time = seq(as.Date("1979-01-01"), as.Date("2017-12-31"), by="month"),
  model.time = seq(as.Date("1979-01-01"), as.Date("2017-12-31"), by="month"),
  model.val.file = "mreco.bin",
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

mod.nee_fluxnet <- IntegrationDataset(
  name="NEE", unit="gC m-2 mon-1",
  data.val.file = paste0(path.geodata1, "ERAinterim.v2.NEE.1979.2017.monthly_QC_flag0d5.nc"),
  data.unc.file = paste0(path.geodata1, "ERAinterim.v2.NEE.1979.2017.monthly_unc_QC_flag0d5.nc"),
  data.time = seq(as.Date("1979-01-01"), as.Date("2017-12-31"), by="month"),
  model.time = seq(as.Date("1979-01-01"), as.Date("2017-12-31"), by="month"),
  model.val.file = "mnep.bin",
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)


mod.fapar <- IntegrationDataset(
  name="FAPAR", unit="-",
  data.val.file = paste0(path.geodata2, "MOD15A2.FAPAR.360.720.2000.2015.30days.nc"),
  data.unc.file = paste0(path.geodata2, "MOD15A2.FAPAR-unc.360.720.2000.2015.30days.nc"),
  data.time = seq(as.Date("2000-01-01"), as.Date("2015-12-01"), by="month"),
  model.time = seq(as.Date("2000-01-01"), as.Date("2011-12-01"), by="month"),
  model.val.file = "mfapar.bin",
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

gfed.ba <- IntegrationDataset(
  name="BA", unit="ha",
  data.val.file = paste0(path.geodata2, "GFED4.BA-nocrop.360.720.1996.2015.30days.nc"),
  data.unc.file = paste0(path.geodata2, "GFED4.BA-nocrop-unc.360.720.1996.2015.30days.nc"),
  data.time = seq(as.Date("1996-01-01"), as.Date("2015-12-01"), by="month"),
  model.time = seq(as.Date("1996-01-01"), as.Date("2011-12-01"), by="month"),
  model.val.file = "mburnt_area.bin",
  xy = grid, AggFun = NULL, data.factor=NULL, cost=FALSE, CostFunction=SSE, weight=1)

avithu.agb <- IntegrationDataset(
  name="AGB", unit="gC m-2",
  data.val.file = paste0(path.geodata2, "AviThu.ABCtree.292.720.2010.2010.0.nc"),
  data.unc.file = paste0(path.geodata2, "AviThu.ABCtree-unc.292.720.2010.2010.0.nc"),
  data.time = as.Date("2010-01-01"),
  model.time = seq(as.Date("2009-01-01"), as.Date("2011-12-01"), by="month"),
  model.val.file = "agb_tree.bin",
  xy = grid, AggFun = AggNULLMean, data.factor=1000, cost=TRUE, CostFunction=SSE, weight=1)

cci.TeBE <- IntegrationDataset(
  name="FPC_TeBE", unit="",
  data.val.file = paste0(path.geodata2, "ESA-CCI-LCv207.TeBE.348.720.1992.2015.365days.nc"),
  data.unc.file = paste0(path.geodata2, "ESA-CCI-LCv207.TeBE_unc.348.720.1992.2015.365days.nc"),
  data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"), # but read data for 1992-2015 with the function:
  model.val.file = function() { # aggregate all herb PFTs
    x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
    x@data <- x@data[, seq(5,ncol(x@data),by=12)]
    return(x)
  },
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

cci.TeBS <- IntegrationDataset(
  name="FPC_TeBS", unit="",
  data.val.file = paste0(path.geodata2, "ESA-CCI-LCv207.TeBS.348.720.1992.2015.365days.nc"),
  data.unc.file = paste0(path.geodata2, "ESA-CCI-LCv207.TeBS_unc.348.720.1992.2015.365days.nc"),
  data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"), # but read data for 1992-2015 with the function:
  model.val.file = function() { # aggregate all herb PFTs
    x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
    x@data <- x@data[, seq(5,ncol(x@data),by=12)]
    return(x)
  },
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

cci.TeNE <- IntegrationDataset(
  name="FPC_TeNE", unit="",
  data.val.file = paste0(path.geodata2, "ESA-CCI-LCv207.TeNE.348.720.1992.2015.365days.nc"),
  data.unc.file = paste0(path.geodata2, "ESA-CCI-LCv207.TeNE_unc.348.720.1992.2015.365days.nc"),
  data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"), # but read data for 1992-2015 with the function:
  model.val.file = function() { # aggregate all herb PFTs
    x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
    x@data <- x@data[, seq(5,ncol(x@data),by=12)]
    return(x)
  },
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

cci.BoBS <- IntegrationDataset(
  name="FPC_BoBS", unit="",
  data.val.file = paste0(path.geodata2, "ESA-CCI-LCv207.BoBS.348.720.1992.2015.365days.nc"),
  data.unc.file = paste0(path.geodata2, "ESA-CCI-LCv207.BoBS_unc.348.720.1992.2015.365days.nc"),
  data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"), # but read data for 1992-2015 with the function:
  model.val.file = function() { # aggregate all herb PFTs
    x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
    x@data <- x@data[, seq(5,ncol(x@data),by=12)]
    return(x)
  },
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

cci.BoNE <- IntegrationDataset(
  name="FPC_BoNE", unit="",
  data.val.file = paste0(path.geodata2, "ESA-CCI-LCv207.BoNE.348.720.1992.2015.365days.nc"),
  data.unc.file = paste0(path.geodata2, "ESA-CCI-LCv207.BoNE_unc.348.720.1992.2015.365days.nc"),
  data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"), # but read data for 1992-2015 with the function:
  model.val.file = function() { # aggregate all herb PFTs
    x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
    x@data <- x@data[, seq(5,ncol(x@data),by=12)]
    return(x)
  },
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

cci.BoNS <- IntegrationDataset(
  name="FPC_BoNS", unit="",
  data.val.file = paste0(path.geodata2, "ESA-CCI-LCv207.BoNS.348.720.1992.2015.365days.nc"),
  data.unc.file = paste0(path.geodata2, "ESA-CCI-LCv207.BoNS_unc.348.720.1992.2015.365days.nc"),
  data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"), # but read data for 1992-2015 with the function:
  model.val.file = function() { # aggregate all herb PFTs
    x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
    x@data <- x@data[, seq(5,ncol(x@data),by=12)]
    return(x)
  },
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

cci.Herb <- IntegrationDataset(
  name="FPC_Herb", unit="",
  data.val.file = paste0(path.geodata2, "ESA-CCI-LCv207.Herb.348.720.1992.2015.365days.nc"),
  data.unc.file = paste0(path.geodata2, "ESA-CCI-LCv207.Herb-unc.348.720.1992.2015.365days.nc"),
  data.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"),
  model.time = seq(as.Date("1992-01-01"), as.Date("2015-01-01"), by="year"), # but read data for 1992-2015 with the function:
  model.val.file = function() { # aggregate all herb PFTs
    x <-  ReadLPJ("fpc.bin", sim.start.year=lpjfiles$sim.start.year, start=1992, end=2015)
    # Herb = TrH + TeH + PoH
    trh <- x@data[, seq(10, ncol(x@data), by=12)]*x@data[, seq(1, ncol(x@data), by=12)] # TrH = 10th PFT
    teh <- x@data[, seq(11, ncol(x@data), by=12)]*x@data[, seq(1, ncol(x@data), by=12)] # TeH = 11th PFT
    poh <- x@data[, seq(12, ncol(x@data), by=12)]*x@data[, seq(1, ncol(x@data), by=12)] # PoH = 12th PFT
    herb <- trh + teh + poh
    x@data <- data.frame(herb) # mean over time
    return(x)
  },
  xy = grid, AggFun = NULL, data.factor=NULL, cost=TRUE, CostFunction=SSE, weight=1)

integrationdata <- IntegrationData(mod.gpp_fluxnet,mod.reco_fluxnet,mod.nee_fluxnet,mod.fapar,cci.BoBS,cci.BoNE,cci.BoNS,cci.Herb,avithu.agb)
#integrationdata <- IntegrationData(avithu.agb,mod.fapar)
#integrationdata <- IntegrationData(mod.gpp_fluxnet,mod.fapar)


#integrationdata <- IntegrationData(fluxcom.gpp)






#integrationdata <- IntegrationData(mod.fapar, avithu.agb)
# make list of IntegrationData
#pdf("out.pdf")
#plot(integrationdata, 1)
#plot(integrationdata, 2)
#dev.off()

#--------------------------------------------------
# 5. Define LPJmL prior parameter values and ranges
#--------------------------------------------------

# Depending on your application, you might need to define additional parameters in param_template.par and pft_template.par


# read parameter priors and ranges from *.txt file
#-------------------------------------------------

# It is helpful to save all parameter names, prior values and prior ranges in a Excel table or *.csv file

setwd(path.lpj.fun)
par.df <- read.table(paste(path.lpj.fun, "inst_lpjml53/LPJmL_parameter-table.csv", sep = ""), header = TRUE, sep = ",")

# remove NA cases
na_rm <- unique(which((is.na(par.df$par.prior))), which((is.na(par.df$par.lower))), which((is.na(par.df$par.upper))))
par.df <- par.df[-na_rm,]

# make LPJpar object
lpjpar <- LPJpar(par.prior=par.df$par.prior, par.lower=par.df$par.lower, par.upper=par.df$par.upper, par.pftspecif=par.df$par.pftspecif, par.names=par.df$par.names, correct=TRUE)

pdf("LPJmL_parameter-table.pdf")
#plot(lpjpar) 
# plot(lpjpar, "ALBEDO_LEAF")
dev.off()

#setwd(paste0(path.lpj, "par/"))
#WriteLPJpar(lpjpar, file="LPJmLmdi_test", pft.par=paste0(path.lpj.fun, "inst_gldas/pft_template.js"), param.par=paste0(path.lpj.fun, "inst_gldas/lpjparam_template.js")) 


# select parameters for optimization
#-----------------------------------
#par.phen <- c("A", "TMIN_BASE", "TMAX_BASE", "TMAX_SLOPE", "WSCAL_BASE", "WSCAL_SLOPE", "LIGHT_BASE", "LIGHT_SLOPE", 
#              "TMIN_TAU", "TMAX_TAU", "WSCAL_TAU", "LIGHT_TAU")


par.optim <- c("BETA_ROOT","ALPHAA","LIGHTEXTCOEFF","TEMP_PHOTOS_HIGH","TEMP_PHOTOS_LOW",
               "TMIN_SLOPE","TMIN_BASE","TMAX_BASE","TMAX_SLOPE","LIGHT_SLOPE","LIGHT_BASE",
               "WSCAL_BASE","WSCAL_SLOPE","LONGEVITY","TURNOVER_SAPWOOD","TURNOVER_LEAF","TURNOVER_ROOT",
               "CROWN_MORT_RCK","K_EST","MORT_MAX","TWMAX_DAILY","GDD5MIN","MIN_TEMPRANGE",
               "TEMP_HIGH","TEMP_LOW")
#par.optim <- c("BETA_ROOT","ALPHAA","LIGHTEXTCOEFF","TEMP_PHOTOS_HIGH","TEMP_PHOTOS_LOW")
pft.sel <- c("BoNE", "BoBS", "BoNS", "TeBE", "TeBS","TeNE","TeH","PoH")
#pft.sel <- c("TrBE", "TrBR", "TrH","TeNE", "TeBE", "TeBS", "TeH","TeNE", "TeBE", "TeBS", "TeH")
# use only parameters that are defined for the PFT

par.optim <- paste(rep(par.optim, each=length(pft.sel)), pft.sel, sep="_")
par.optim <- par.optim[par.optim %in% lpjpar$names]

#par.optim <- c(par.optim, "K_MORT", "UP_T_M", "T_O", "T_R")

# exclude 'inactive' parameters, including those with (nearly) identical upper and lower bounds
b <- match(par.optim, lpjpar$names)
rem <- lpjpar$prior[b] == 999 | lpjpar$prior[b] == -999 | abs(lpjpar$upper[b]-lpjpar$lower[b])<1e-6
par.optim <- par.optim[!rem]
par.optim



# For which PFTs?
#pft.sel <- c("BoNS", "PoH")
#par.optim <- paste(rep(par.optim, each=length(pft.sel)), pft.sel, sep="_")
#par.optim


#------------------------
# 6. Perform optimization
#------------------------


# do optimization
OptimizeLPJgenoud(xy = grid, 				# matrix of grid cell coordinates to run LPJ
                  name = name, 							# name of the experiment (basic file name for all outputs)
                  lpjpar = lpjpar,						# see LPJpar
                  par.optim = par.optim,			        # names of the parameters in LPJpar that should be optimized
                  lpjfiles = lpjfiles,					# see LPJfiles
                  copy.input = FALSE, 						# Should LPJmL input data be copied to the directory for temporary output? 
                  integrationdata = integrationdata,		# see IntegrationData
                  plot = TRUE,							# plot results?
                  pop.size = pop.size, 					# population size
                  max.generations = max.generations, 		# max number of generations
                  wait.generations = wait.generations,	# minimum number of generations to wait
                  BFGSburnin = BFGSburnin,				# number of generations before the gradient search algorithm if first used
                  calc.jacob = FALSE, 					# Compute Hessian and Jacobian (yes = TRUE, no = FALSE)?
                  restart = restart, 						# Restart? 0 = at beginning, 1 = continue with genoud, 2 = post-processing
                  path.rescue = path.rescue, 				# directory with 'resuce' files from a previous optimization if restart > 0
                  restart.jacob = FALSE, 					# Compute Hessian and Jacobian if restart > 0 (yes = TRUE, no = FALSE)? 
                  nodes = nodes, 							# How many nodes to use for parallel computing within genoud?
                  maxAutoRestart = max.generations-1, 	# maximum number of automatic restarts in case something crashes
                  warnings = TRUE,
                  runonly=FALSE,							# make only model run (TRUE) or do full optimization?
                  CostMDS=CostMDS)						# Cost function for multiple data stes to use


# # check the progress of the optimization:
#setwd("/p/projects/biodiversity/drueke/internal_lpjml/out_optim/opt_Example/Opt_test4/Opt_test4_rescue") # directory with rescue files
#files <- list.files(pattern=".RData") 
#rescue <- CombineRescueFiles(files, remove=FALSE)
#pdf("progress.pdf")
#plot(rescue)
#dev.off()
