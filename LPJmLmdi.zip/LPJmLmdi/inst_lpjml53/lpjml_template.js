/**************************************************************************************/
/**                                                                                \n**/
/**                   l  p  j  m  l  _  t  e  m  p  l  a  t  e  .  j  s            \n**/
/**                                                                                \n**/
/** Configuration file for LPJmL C Version 5.3.001                                 \n**/
/**                                                                                \n**/
/** Configuration file is divided into five sections:                              \n**/
/**                                                                                \n**/
/**  I.   Simulation description and type section                                  \n**/
/**  II.  Input parameter section                                                  \n**/
/**  III. Input data section                                                       \n**/
/**  IV.  Output data section                                                      \n**/
/**  V.   Run settings section                                                     \n**/
/**                                                                                \n**/
/** (C) Potsdam Institute for Climate Impact Research (PIK), see COPYRIGHT file    \n**/
/** authors, and contributors see AUTHORS file                                     \n**/
/** This file is part of LPJmL and licensed under GNU AGPL Version 3               \n**/
/** or later. See LICENSE file or go to http://www.gnu.org/licenses/               \n**/
/** Contact: https://github.com/PIK-LPJmL/LPJmL                                    \n**/
/**                                                                                \n**/
/**************************************************************************************/

#include "include/conf.h" /* include constant definitions */

//#define DAILY_OUTPUT  /* enables daily output */

{   /* LPJmL configuration in JSON format */

/*===================================================================*/
/*  I. Simulation description and type section                       */
/*===================================================================*/

  "sim_name" : "LPJmL Run", /* Simulation description */
  "sim_id"   : "lpjml",     /* LPJML Simulation type with managed land use */
  "version"  : "5.3",       /* LPJmL version expected */
  "random_prec" : false,     /* Random weather generator for precipitation enabled */
  "random_seed" : 2,        /* seed for random number generator */
  "radiation" : "radiation_lwdown",/* other options: CLOUDINESS, RADIATION, RADIATION_SWONLY, RADIATION_LWDOWN */
  "fire" : "no_fire", /* fire disturbance enabled, other options: NO_FIRE, FIRE, SPITFIRE, SPITFIRE_TMAX (for GLDAS input data) */
  "fdi" : "nesterov",       /* different fire danger index formulations: WVPD_INDEX(needs GLDAS input data), NESTEROV_INDEX*/
  "firewood" : false,
  "new_phenology": true,    /* GSI phenology enabled */
  "river_routing" : false,
  "permafrost" : true,
  "firestop" : true,
  "store_climate" : true,
  "const_climate" : false,
  "shuffle_climate" : true,
  "const_deposition" : false,
  "with_nitrogen" : "lim", /* other options: no, lim, unlim */
  "const_climate" : false,
  "const_deposition" : false,
  "no_ndeposition" :  false,
  "fix_climate" : false,
#ifdef FROM_RESTART
  "new_seed" : false, /* read random seed from restart file */
  "equilsoil" : false,
  "population" : false,
  "landuse" : "no", /* other options: NO_LANDUSE, LANDUSE, CONST_LANDUSE, ALL_CROPS */
  "landuse_year_const" : 2000, /* set landuse year for CONST_LANDUSE case */
  "reservoir" : false,
  "wateruse" : "no",  /* other options: NO_WATERUSE, WATERUSE, ALL_WATERUSE */
#else
  "equilsoil" : true,
  "population" : false,
  "landuse" : "no",
  "reservoir" : false,
  "wateruse" : "no",
#endif
  "prescribe_burntarea" : false,
  "prescribe_landcover" : "no_landcover", /* NO_LANDCOVER, LANDCOVERFPC, LANDCOVEREST */
  "sowing_date_option" : "fixed_sdate",   /* NO_FIXED_SDATE, FIXED_SDATE, PRESCRIBED_SDATE */
  "sdate_fixyear" : 1970,               /* year in which sowing dates shall be fixed */
  "intercrop" : true,                   /* intercrops on setaside */
  "remove_residuals" : false,           /* remove residuals */
  "residues_fire" : false,              /* fire in residuals */
  "irrigation" : "lim",        /* NO_IRRIGATION, LIM_IRRIGATION, POT_IRRIGATION, ALL_IRRIGATION */
  "laimax_interpolate" : "laimax_par", /* laimax values from manage parameter file, */
                                        /* other options: LAIMAX_CFT, CONST_LAI_MAX, LAIMAX_INTERPOLATE, LAIMAX_PAR  */
  "rw_manage" : false,                  /* rain water management */
  "laimax" : 5,                         /* maximum LAI for CONST_LAI_MAX */
  "fertilizer_input" : true,            /* enable fertilizer input */
  "istimber" : true,
  "grassland_fixed_pft" : false,
  "grass_harvest_options" : false,
  "crop_phu_option" : "new",           /* other options: "old", "new", "prescribed" */
  "black_fallow" : false,
  "new_trf" : true,
  "johansen" : true,

/*===================================================================*/
/*  II. Input parameter section                                      */
/*===================================================================*/

#include "CELL_PARCONF_FILE"     /* Input parameter file */

/*===================================================================*/
/*  III. Input data section                                          */
/*===================================================================*/

#include "CELL_INPUT_FILE"    /* Input files of CRU dataset */

/*===================================================================*/
/*  IV. Output data section                                          */
/*===================================================================*/

#ifdef WITH_GRIDBASED
  "grid_scaled" : true, /* PFT-specific outputs scaled by stand->frac */
#define SUFFIX grid.bin
#else
  "grid_scaled" : false,
#define SUFFIX pft.bin
#endif

#define mkstr(s) xstr(s) /* putting string in quotation marks */
#define xstr(s) #s

  "crop_index" : "temperate cereals",  /* CFT for daily output */
  "crop_irrigation" : false,           /* irrigation flag for daily output */

#ifdef FROM_RESTART

  "output" : 
  [

/*
ID                         Fmt                    filename
-------------------------- ---------------------- ----------------------------- */
    { "id" : "grid",            "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/grid.bin" }},
    { "id" : "fpc",             "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/fpc.bin"}},
    { "id" : "gpp",             "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/mgpp.bin"}},
    { "id" : "r_eco",             "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/mreco.bin"}},
    { "id" : "nep",             "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/mnep.bin"}},
    { "id" : "npp",             "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/mnpp.bin"}},
    { "id" : "rh",             "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/mrh.bin"}},
    { "id" : "firec",           "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/firec.bin"}},
    { "id" : "vegc",            "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/vegc.bin"}},
    { "id" : "soilc",           "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/soilc.bin"}},
    { "id" : "litc",            "file" : { "fmt" : "raw", "name" : "CELL_OUTPATHlitc.bin"}},
    { "id" : "burntarea",       "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/mburnt_area.bin"}},
    { "id" : "albedo",          "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/malbedo.bin"}},
    { "id" : "agb",             "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/agb.bin"}},
    { "id" : "agb_tree",        "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/agb_tree.bin"}},
    { "id" : "fapar",           "file" : { "fmt" : "raw", "name" : "CELL_OUTPATH/mfapar.bin"}}
/*----------------------- ---------------------- ------------------------------- */
  ],


#else

  "output" : [],  /* no output written */

#endif

/*===================================================================*/
/*  V. Run settings section                                          */
/*===================================================================*/

  "startgrid" : CELL_START, /* 27410, 67208 60400 all grid cells */
  "endgrid" : CELL_END,

#ifdef CHECKPOINT
  "checkpoint_filename" : "restart/restart_checkpoint.lpj", /* filename of checkpoint file */
#endif

#ifndef FROM_RESTART

  "nspinup" : 10000,  /* spinup years */
  "nspinyear" : 30,  /* cycle length during spinup (yr) */
  "firstyear": YEAR_START, /* first year of simulation */
  "lastyear" : YEAR_START, /* last year of simulation */
  "restart" : false, /* do not start from restart file */
  "write_restart" : true, /* create restart file: the last year of simulation=restart-year */
  "write_restart_filename" : "CELL_RESTART_FILE", /* filename of restart file */
  "restart_year": YEAR_START /* write restart at year */

#else

  "nspinup" : 390,   /* spinup years */
  "nspinyear" : 30,  /* cycle length during spinup (yr)*/
  "firstyear": YEAR_START, /* first year of simulation */
  "lastyear" : YEAR_END, /* last year of simulation */
  "outputyear": YEAR_START, /* first year output is written  */
  "restart" :  true, /* start from restart file */
  "restart_filename" : "CELL_RESTART_FILE", /* filename of restart file */
  "write_restart" : false, /* create restart file */
  "write_restart_filename" : "restart/restart_1900_crop_stdfire.lpj", /* filename of restart file */
  "restart_year": YEAR_START /* write restart at year */

#endif
}
